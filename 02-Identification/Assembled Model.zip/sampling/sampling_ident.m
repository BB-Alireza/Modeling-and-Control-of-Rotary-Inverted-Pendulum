clc;
x1=X.data;
y1=y.data;